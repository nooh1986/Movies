<a href="">
    <img src="{{ $actor->profile_path }}" style="width: 100px;" alt="">
</a>