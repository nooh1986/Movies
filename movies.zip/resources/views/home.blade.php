@extends('layouts.app')

@section('content')

    <div>
        <h2>Home</h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item">Home</li>
    </ul>
        
@endsection

