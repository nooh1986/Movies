<a href="<?php echo e(route ('movies.show' , $movie->id)); ?>">
    <img src="<?php echo e($movie->poster_path); ?>" style="width: 100px;" alt="">
</a><?php /**PATH C:\Users\nooha\OneDrive\Desktop\Movies\resources\views/moives/data_table/poster.blade.php ENDPATH**/ ?>