

<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('movies.movies'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('movies.index')); ?>">Movies</a></li>
        <li class="breadcrumb-item">SHOW</li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <div class="row">
                    <div class="col-md-2">
                        <img src="<?php echo e($movie->poster_path); ?>" class="img-fluid" alt="">
                    </div>

                    <div class="col-md-10">
                        <h2><?php echo e($movie->title); ?></h2>

                        <?php $__currentLoopData = $movie->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5 class="d-inline-block"><span class="badge badge-primary"><?php echo e($genre->name); ?></span></h5>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <p style="font-size: 16px;"><?php echo e($movie->description); ?></p>

                        <div class="d-flex mb-2">
                            <i class="fa fa-star text-warning" style="font-size: 35px;"></i>
                            <h3 class="m-0 mx-2"><?php echo e($movie->vote); ?></h3>
                            <p class="m-0 align-self-center"><?php echo app('translator')->get('movies.by'); ?> <?php echo e($movie->vote_count); ?></p>
                        </div>

                        <p><span class="font-weight-bold">Language</span>: en</p>
                        <p><span class="font-weight-bold">Release Date</span>: <?php echo e($movie->release_data); ?></p>

                        <hr>

                        <div class="row" id="movie-images">

                            <?php $__currentLoopData = $movie->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-md-3 my-2">
                                    <a href="<?php echo e($image->name_path); ?>"><img src="<?php echo e($image->name_path); ?>" class="img-fluid" alt=""></a>
                                </div><!-- end of col -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div><!-- end of row -->

                        <hr>

                        <div class="row">

                            <?php $__currentLoopData = $movie->actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-md-2 my-2">
                                    <a href="">
                                        <img src="<?php echo e($actor->profile_path); ?>" class="img-fluid" alt="">
                                    </a>
                                </div><!-- end of col -->

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div><!-- end of row -->

                    </div><!-- end of col  -->

                </div><!-- end of row -->

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script>
        $(function () {

            $('#movie-images').magnificPopup({
                delegate: 'a', // the selector for gallery item
                type: 'image',
                gallery: {
                    enabled: true
                }
            });

        });//end of document ready

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nooha\OneDrive\Desktop\Movies\resources\views/moives/show.blade.php ENDPATH**/ ?>