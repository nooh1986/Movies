<a href="">
    <img src="<?php echo e($actor->profile_path); ?>" style="width: 100px;" alt="">
</a><?php /**PATH C:\Users\nooha\OneDrive\Desktop\Movies\resources\views/actores/data_table/profile.blade.php ENDPATH**/ ?>