<div class="animated-checkbox">
    <label class="m-0">
        <input type="checkbox" class="record__select" value="<?php echo e($id); ?>">
        <span class="label-text"></span>
    </label>
</div><?php /**PATH C:\Users\nooha\OneDrive\Desktop\Movies\resources\views/genres/data_table/record_select.blade.php ENDPATH**/ ?>